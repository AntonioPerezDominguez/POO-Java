/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Archivos;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 *
 * @author Antonio
 */
public class AccesoAleatorio {
    public static void main(String[] args) {
        File archivo = new File("aleatorio.ale");
        try {
            /*modos de apertura
            r--> solo leer
            rw--> modo lectura y escritura
            rwd---> modo lectura y escitura es sincrono
            rws---> modo lectura y escritura es asincrono
            */
            RandomAccessFile raf = new RandomAccessFile(archivo,"rw");
            raf.seek(0);
            raf.writeFloat(64.00f);
            raf.write(64);
            
        } catch (FileNotFoundException ex) {
           ex.printStackTrace();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        
    }
}
