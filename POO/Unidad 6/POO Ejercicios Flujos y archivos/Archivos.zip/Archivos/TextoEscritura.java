/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Archivos;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Antonio
 */
public class TextoEscritura {
    public static void main(String[] args) {
        try{
        File archivo = new File("text.txt");
        if(!archivo.exists()){
            archivo.createNewFile();
        }
        FileWriter escritor = new FileWriter(archivo,true);
        escritor.write(90);
        escritor.write("Mi primer texto en archivos de escritura");
        //char [] chars={'10','2','3','4','5'};
        escritor.flush();
        escritor.close();
        }catch(IOException e){
            
        }
    }
}
