/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Archivos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Antonio
 */
public class TextoLectura {

    public static void main(String[] args) throws IOException {
        try {
            File archivo = new File("text.txt");
            FileReader lector = new FileReader(archivo);
            int c = 0;
            while (c != -1) {
                c = lector.read();
                System.out.println((char) c);
            }
            BufferedReader br = new BufferedReader(lector);
            String linea = br.readLine();
            lector.close();
            
        } catch (FileNotFoundException e) {

        }
    }
}
