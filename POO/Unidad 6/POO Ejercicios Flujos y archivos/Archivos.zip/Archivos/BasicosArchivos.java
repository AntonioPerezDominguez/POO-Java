/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Archivos;

import java.io.*;
/**
 *
 * @author Antonio
 */
public class BasicosArchivos {
    public static void main(String[] args) {
        File f1=new File("C:\\Users\\Antonio\\Documents\\NetBeansProjects\\datos.txt");
        try{
           if(!f1.exists()){
            f1.createNewFile();
                System.out.println("name: "+f1.getName());
                 System.out.println("path: "+f1.getPath());
                 System.out.println("rura absoluta: "+f1.getAbsolutePath());
                 System.out.println("ruta canonica: "+f1.getCanonicalPath());
                 System.out.println("Padre: "+f1.getParent());
                 System.out.println("Absoluto: "+f1.isAbsolute());
                 System.out.println("Feacha en segundos: "+f1.lastModified());
                 System.out.println("Tamño: "+f1.length());
            }
        }catch(IOException e){
            e.printStackTrace();// pila de lllamadas para ubicar el metodo y la linea de escpetion
        }
        
    }
}
