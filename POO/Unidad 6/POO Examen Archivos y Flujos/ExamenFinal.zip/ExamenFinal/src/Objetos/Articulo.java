 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objetos;

import java.util.Objects;

/**
 *
 * @author david
 */
public class Articulo {
    private String clave;
    private String nombreCorto;
    private String descripcion;
    private float existenciaMinima;
    private float costo;
    private String unidadMedida;
    private float precio;
    private boolean activo;

    public Articulo(String clave, String nombreCorto, String descripcion, float existenciaMinima, float costo, String unidadMedida, float precio, boolean activo) {
        this.clave = clave;
        this.nombreCorto = nombreCorto;
        this.descripcion = descripcion;
        this.existenciaMinima = existenciaMinima;
        this.costo=costo;
        this.unidadMedida = unidadMedida;
        this.precio = precio;
        this.activo = activo;
    }

    public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getNombreCorto() {
        return nombreCorto;
    }

    public void setNombreCorto(String nombreCorto) {
        this.nombreCorto = nombreCorto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getExistenciaMinima() {
        return existenciaMinima;
    }

    public void setExistenciaMinima(float existenciaMinima) {
        this.existenciaMinima = existenciaMinima;
    }

    public String getUnidadMedida() {
        return unidadMedida;
    }

    public void setUnidadMedida(String unidadMedida) {
        this.unidadMedida = unidadMedida;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    @Override
    public String toString() {
        return "Articulo{" + "clave=" + clave + ", nombreCorto=" + nombreCorto + ", descripcion=" + descripcion + ", existenciaMinima=" + existenciaMinima + ", costo=" + costo + ", unidadMedida=" + unidadMedida + ", precio=" + precio + ", activo=" + activo + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.clave);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Articulo other = (Articulo) obj;
        if (!Objects.equals(this.clave, other.clave)) {
            return false;
        }
        return true;
    }

   
    

    
    
}
