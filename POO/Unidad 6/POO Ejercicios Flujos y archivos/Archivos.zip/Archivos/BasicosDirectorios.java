/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Archivos;
import java.io.*;
/**
 *
 * @author Antonio
 */
public class BasicosDirectorios {
    public static void main(String[] args) {
        File carpeta =new File("folder");
        System.out.println("existe: "+carpeta.exists());
        if(!carpeta.exists()){
            carpeta.mkdir();
            System.out.println("directorio: "+carpeta.isDirectory());
            System.out.println("escritura: "+carpeta.canWrite());
            System.out.println("lectura: "+carpeta.canRead());
            
            System.out.println("Contenido");
            String[] contenido= carpeta.list();
            for(String e: contenido){
                System.out.println(e);
            }
            
        }
    }
}
